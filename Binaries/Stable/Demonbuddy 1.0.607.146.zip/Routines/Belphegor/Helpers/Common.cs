﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Zeta;
using Zeta.Common.Helpers;
using Zeta.Internals.Actors;
using Zeta.TreeSharp;
using Action = Zeta.TreeSharp.Action;
using Zeta.Common;

namespace Belphegor.Helpers
{
    public static class Common
    {
        public static Composite CreateWaitWhileIncapacitated()
        {
            return
                new Decorator(ret => 
                    ZetaDia.Me.IsFeared ||
                    ZetaDia.Me.IsStunned ||
                    ZetaDia.Me.IsFrozen ||
                    ZetaDia.Me.IsBlind ||
                    ZetaDia.Me.IsRooted, 

                    new Action(ret => RunStatus.Success)
                );
        }

        public static Composite CreateWaitForAttack()
        {
            return 
                new Decorator(ret => ZetaDia.Me.CommonData.AnimationState == AnimationState.Attacking,
                    new Action(ret => RunStatus.Success)
                );
                
        }

        private static WaitTimer _potionCooldownTimer = WaitTimer.ThirtySeconds;
        public static Composite CreateUsePotion(double healthpct = 0.4)
        {
            return
                new Decorator(ret => ZetaDia.Me.HitpointsCurrentPct <= healthpct && _potionCooldownTimer.IsFinished,
                    new PrioritySelector(ctx => ZetaDia.Me.Inventory.Backpack.Where(i => i.IsPotion && i.RequiredLevel <= ZetaDia.Me.Level).OrderByDescending(p => p.HitpointsGranted).FirstOrDefault(),

                        new Decorator(ctx => ctx != null,
                            new Sequence(
                                new Action(ctx => ZetaDia.Me.Inventory.UseItem(((ACDItem)ctx).DynamicId)),
                                new Action(ctx => _potionCooldownTimer.Reset()),
                                new Action(ctx => Logger.Write("Potion set to use below {0}%, my health is currently {1}%, using {2}",100*healthpct, Math.Round(100*ZetaDia.Me.HitpointsCurrentPct), ((ACDItem)ctx).Name))
                //new Action(ctx => Logger.Write("Using health potion at {0}% health.", (int)ZetaDia.Me.HitpointsCurrentPct))
                                )
                            )
                        )
                    );
        }

        /// <summary>
        /// Checks if the mob is Elite or Rare
        /// </summary>
        /// <param name="unit">DiaUnit</param>
        /// <returns></returns>
        public static bool IsElite(DiaUnit unit)
        {
            if (unit.CommonData.MonsterAffixes.HasFlag(MonsterAffixes.Elite))
            {
                Logging.WriteVerbose("{0} Is an Elite Mob", unit.Name);
                return true;
            }

            if (unit.CommonData.MonsterAffixes.HasFlag(MonsterAffixes.Rare))
            {
                Logging.WriteVerbose("{0} Is a Rare Mob", unit.Name);
                return true;
            }

            if (unit.CommonData.MonsterAffixes.HasFlag(MonsterAffixes.Unique))
            {
                Logging.WriteVerbose("{0} Is a Unique Mob", unit.Name);
                return true;
            }

            else
            {
                //Logging.WriteVerbose("{0} Is NOT an Elite or Rare", unit.Name);
                return false;
            }
        }
    }
}
