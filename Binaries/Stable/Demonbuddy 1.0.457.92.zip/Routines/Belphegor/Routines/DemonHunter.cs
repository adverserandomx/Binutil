﻿using System;
using Belphegor.Dynamics;
using Belphegor.Helpers;
using Zeta;
using Zeta.CommonBot;
using Zeta.Internals.Actors;
using Zeta.TreeSharp;
using Action = Zeta.TreeSharp.Action;

namespace Belphegor.Routines
{
    public class DemonHunter
    {
        [Class(ActorClass.DemonHunter)]
        [Behavior(BehaviorType.Combat)]
        public static Composite DemonHunterCombat()
        {
            return
               new PrioritySelector(ctx => CombatTargeting.Instance.FirstNpc,

                   new Decorator(ctx => ctx != null,
                       new PrioritySelector(

                           new Decorator(ctx => ctx != null && ((DiaUnit)ctx).Distance > 30f,
                            CommonBehaviors.MoveTo(ctx => ((DiaUnit)ctx).Position, "Moving towards unit")
                            ),
                           
                            // Secondary
                            Spell.CastAtLocation(SNOPower.DemonHunter_Impale, ctx => ((DiaUnit)ctx).Position),

                           // Primary
                           Spell.CastAtLocation(SNOPower.DemonHunter_HungeringArrow, ctx => ((DiaUnit)ctx).Position)
                       )
                   ),

                   new Action(ret => RunStatus.Success)
                   );
        }

        public static void DemonHunterOnLevelUp(object sender, EventArgs e)
        {
            if (ZetaDia.Me.ActorClass != ActorClass.DemonHunter)
                return;

            int myLevel = ZetaDia.Me.Level;

            Logger.Write("Player leveled up, congrats! Your level is now: {0}",
                myLevel
                );

            if (myLevel == 2)
            {
                ZetaDia.Me.SetActiveSkill(SNOPower.DemonHunter_Impale, -1, 1);
                Logger.Write("Setting Impale as Secondary skill");
            }

            if (myLevel == 4)
            {
                ZetaDia.Me.SetActiveSkill(SNOPower.DemonHunter_Caltrops, -1, 2);
                Logger.Write("Setting Caltrops as Defensive skill");
            }

            if (myLevel == 5)
            {
                ZetaDia.Me.SetActiveSkill(SNOPower.DemonHunter_RapidFire, -1, 1);
                Logger.Write("Setting Rapid Fire as Secondary skill");
            }

            if (myLevel == 8)
            {
                ZetaDia.Me.SetActiveSkill(SNOPower.DemonHunter_SmokeScreen, -1, 1);
                Logger.Write("Setting Smoke Screen as Defensive skill");
            }

            if (myLevel == 9)
            {
                ZetaDia.Me.SetActiveSkill(SNOPower.DemonHunter_Vault, -1, 3);
                Logger.Write("Setting Vault as Hunting skill");
            }
        }
    }
}
