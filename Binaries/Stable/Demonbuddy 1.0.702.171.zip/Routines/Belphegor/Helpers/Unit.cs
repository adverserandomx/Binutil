﻿using Zeta;
using Zeta.Internals.Actors;
using System.Linq;

namespace Belphegor.Helpers
{
    internal static class Unit
    {
        /// <summary>
        /// Checks if the mob is Elite or Rare
        /// </summary>
        /// <param name="unit">DiaUnit</param>
        /// <returns>True if Current unit is Elite</returns>
        public static bool IsElite(this DiaUnit unit)
        {
            if (unit.CommonData.MonsterAffixes.HasFlag(MonsterAffixes.Elite))
            {
                Logger.WriteVerbose("{0} Is an Elite Mob", unit.Name);
                return true;
            }
            if (unit.CommonData.MonsterAffixes.HasFlag(MonsterAffixes.Rare))
            {
                Logger.WriteVerbose("{0} Is a Rare Mob", unit.Name);
                return true;
            }
            if (unit.CommonData.MonsterAffixes.HasFlag(MonsterAffixes.Unique))
            {
                Logger.WriteVerbose("{0} Is a Unique Mob", unit.Name);
                return true;
            }
            if (unit.Name.StartsWith("treasureGoblin"))
            {
                Logger.WriteVerbose("Mob is a Treasure Goblin");
                return true;
            }
            else return false;
        }

        /// <summary>
        /// Checks if the mob is Elite or Rare && with range
        /// </summary>
        /// <param name="unit">DiaUnit</param>
        /// <param name="range">Range from us to unit</param>
        /// <returns>True if Current usint is Elite && unit is in rnage</returns>
        public static bool IsElite(this DiaUnit unit, float range)
        {
            return IsElite(unit) && unit.Distance <= range;
        }

        /// <summary>
        /// Checks if we are Blind, Feared, Frozen, Stunned or Rooted
        /// </summary>
        public static bool MeIncapacited
        {
            get
            {
                var Me = ZetaDia.Me;
                return Me.IsFeared || Me.IsStunned || Me.IsFrozen || Me.IsBlind || Me.IsRooted;
            }
        }

        /// <summary>
        /// Do you have a Pet
        /// </summary>
        /// <param name="PetName">From RActors</param>
        /// <returns></returns>
        public static bool HasPet(this string PetName)
        {
            if (PetCount(PetName) >= 1)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Scan to see how many pets you have
        /// </summary>
        /// <param name="PetName">From RActors</param>
        /// <returns>Count of peets</returns>
        public static int PetCount(this string PetName)
        {
            ZetaDia.Actors.Update();
            int DynId = ZetaDia.Me.CommonData.DynamicId;
            var Units = ZetaDia.Actors.GetActorsOfType<DiaUnit>(false, false).Where(u => u.CommonData != null).ToList();
            if (DynId != null && Units != null)
            {
                var SummonedByMe = Units.Where(u => u.SummonedByACDId == DynId).ToList();
                if (SummonedByMe != null)
                {
                    var count = SummonedByMe.Where(u => u.Name.Contains(PetName)).Count();
                    return count;
                }
            }
            // Note the reason i dont return 0
            // is so if there is an error 
            // then we basically return false
            return 10;
        }
        


    }
}
