	      Mammon - The Prince of Greed
-------------------------------------------------------

Disclaimer: I do not claim i have written the base for
this combat routine, Mammon is a forked build of
Belphegoor! So credtis to the Buddyteam its a really
good starting point for any custom class.


Credits to Diktat who came up with the brilliant name,
since Belphegor already had a name from demonology it
only seems fitting to use the same, not even to mention
Mammon was also known as the Prince of Greed.


Mammon is a term derived from the Christian Bible used 
to describe material wealth or greed, most often 
personified as a deity, and sometimes included in 
the seven princes of Hell. Ref: Wikipedia.


In all essence Mammon will be exactly the same as
Belphegor except improved class routines, there will
be small changes in the code but i will keep it to a
minimum. This way the code can easily be put directly
into Belphegor if the developer team of Demonbuddy 
would like to use my improvements in their own release
of Demonbuddy.

-------------------------------------------------------
Date: 13.06.2012			Author: j0achim
-------------------------------------------------------
