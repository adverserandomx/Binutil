﻿using System;
using Mammon.Dynamics;
using Mammon.Helpers;
using Zeta;
using Zeta.Common;
using Zeta.CommonBot;
using Zeta.Internals.Actors;
using Zeta.Navigation;
using Zeta.TreeSharp;
using Action = Zeta.TreeSharp.Action;

namespace Mammon.Routines
{
    public class Monk
    {
        [Class(ActorClass.Monk)]
        [Behavior(BehaviorType.Combat)]
        public static Composite MonkCombat()
        {
            return
                new PrioritySelector(ctx => CombatTargeting.Instance.FirstNpc,
                    MonkBuffs(),
                new Decorator(ctx => ctx != null,
                    new PrioritySelector(
                        new Decorator(ctx => ctx != null && ((DiaUnit)ctx).Distance > 20f,
                            CommonBehaviors.MoveTo(ctx => ((DiaUnit)ctx).Position, "Moving towards unit")
                        ),

                        // Use Breath of heaven if it's active and we have low health.
                        Spell.CastAOESpell(SNOPower.Monk_BreathOfHeaven, 
                            extra => ZetaDia.Me.HitpointsCurrentPct <= 0.1),

                        // Binding flash if we have it.
                        Spell.CastAOESpell(SNOPower.Monk_BlindingFlash, 
                            extra => Clusters.GetClusterCount(ZetaDia.Me, CombatTargeting.Instance.LastObjects, ClusterType.Radius, 20f) >= 5),

                        // Spirit spender, don't waste it unless we have 3 mobs near.
                        Spell.CastAtLocation(SNOPower.Monk_LashingTailKick, ret => CombatTargeting.Instance.FirstNpc.Position,
                            extra => Clusters.GetClusterCount(ZetaDia.Me, CombatTargeting.Instance.LastObjects, ClusterType.Radius, 20f) >= 3),

                        // Use this prior to FOT if we can use it.
                        Spell.CastAtLocation(SNOPower.Monk_DeadlyReach, ret => CombatTargeting.Instance.FirstNpc.Position),

                        // First spell we use, check this last. 
                        Spell.CastAtLocation(SNOPower.Monk_FistsofThunder, ret => CombatTargeting.Instance.FirstNpc.Position)
                        )
                    ),

                    new Action(ret => RunStatus.Success)
                );
        }

        private static Composite MonkBuffs()
        {
            return new PrioritySelector(
                Spell.Buff(SNOPower.Monk_MantraOfEvasion),
                Spell.Buff(SNOPower.Monk_MantraOfConviction),
                Spell.Buff(SNOPower.Monk_MantraOfHealing),
                Spell.Buff(SNOPower.Monk_MantraOfRetribution)
                );
        }

        public static void MonkOnLevelUp(object sender, EventArgs e)
        {
            if (ZetaDia.Me.ActorClass != ActorClass.Monk)
                return;

            int myLevel = ZetaDia.Me.Level;

            Logger.Write("Player leveled up, congrats! Your level is now: {0}",
                myLevel
                );

            // Set Lashing tail kick once we reach level 2
            if (myLevel == 2)
            {
                ZetaDia.Me.SetActiveSkill(SNOPower.Monk_LashingTailKick, -1, 1);
                Logger.Write("Setting Lash Tail Kick as Secondary");
            }

            // Set Dead reach it's better then Fists of thunder imo.
            if (myLevel == 3)
            {
                ZetaDia.Me.SetActiveSkill(SNOPower.Monk_DeadlyReach, -1, 0);
                Logger.Write("Setting Deadly Reach as Primary");
            }

            // Make sure we set binding flash, useful spell in crowded situations!
            if (myLevel == 4)
            {
                ZetaDia.Me.SetActiveSkill(SNOPower.Monk_BlindingFlash, -1, 2);
                Logger.Write("Setting Binding Flash as Defensive");
            }

            // Binding flash is nice but being alive is even better!
            if (myLevel == 8)
            {
                ZetaDia.Me.SetActiveSkill(SNOPower.Monk_BreathOfHeaven, -1, 2);
                Logger.Write("Setting Breath of Heaven as Defensive");
            }

            // Make sure we set Dashing strike, very cool and useful spell great opener.
            if (myLevel == 9)
            {
                ZetaDia.Me.SetActiveSkill(SNOPower.Monk_DashingStrike, -1, 3);
                Logger.Write("Setting Dashing Strike as Techniques");
            }
        }
    }
}
