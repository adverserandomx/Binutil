﻿using Belphegor.Dynamics;
using Zeta.Internals.Actors;
using Zeta.TreeSharp;

namespace Belphegor.Routines
{
    public class Invalid
    {
        [Class(ActorClass.Invalid)]
        [Behavior(BehaviorType.All)]
        public static Composite InvalidWrapper()
        {
            return new PrioritySelector(
                new Action(ret => Logger.Write("Blah!"))
                );
        }
    }
}
