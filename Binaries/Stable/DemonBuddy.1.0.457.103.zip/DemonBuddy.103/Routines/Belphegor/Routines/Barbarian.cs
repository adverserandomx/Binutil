﻿using System;
using Belphegor.Dynamics;
using Belphegor.Helpers;
using Zeta;
using Zeta.Common;
using Zeta.CommonBot;
using Zeta.Internals.Actors;
using Zeta.TreeSharp;
using Action = Zeta.TreeSharp.Action;

namespace Belphegor.Routines
{
    public class Barbarian
    {
        [Class(ActorClass.Barbarian)]
        [Behavior(BehaviorType.Combat)]
        public static Composite BarbarianCombat()
        {
            return
                new PrioritySelector(ctx => CombatTargeting.Instance.FirstNpc,

                    new Decorator(ctx => ctx != null,
                        new PrioritySelector(

                             // Use Leap if possible.
                            Spell.CastAtLocation(SNOPower.Barbarian_Leap, ctx => ((DiaUnit)ctx).Position),
                            Spell.CastAtLocation(SNOPower.Barbarian_AncientSpear, ret => CombatTargeting.Instance.FirstNpc.Position),

                            // Move to the unit.
                            new Decorator(ctx => ctx != null && ((DiaUnit)ctx).Distance > 15f,
                                CommonBehaviors.MoveTo(ctx => ((DiaUnit)ctx).Position, "Moving towards unit")
                            ),

                            // Gound stomp if we can.
                            Spell.CastAOESpell(SNOPower.Barbarian_GroundStomp,
                                extra => Clusters.GetClusterCount(ZetaDia.Me, CombatTargeting.Instance.LastObjects, ClusterType.Radius, 12f) >= 4
                            ),

                            // Fury spenders.
                            Spell.CastAtLocation(SNOPower.Barbarian_HammerOfTheAncients, ctx => ((DiaUnit)ctx).Position),

                            // Fury Generators
                            Spell.CastAtLocation(SNOPower.Barbarian_Cleave, ret => CombatTargeting.Instance.FirstNpc.Position),
                            Spell.CastAtLocation(SNOPower.Barbarian_Bash, ret => CombatTargeting.Instance.FirstNpc.Position)
                        )
                    ),

                    new Action(ret => RunStatus.Success)
                    );
        }

        public static void BarbarianOnLevelUp(object sender, EventArgs e)
        {
            if (ZetaDia.Me.ActorClass != ActorClass.Barbarian)
                return;

            int myLevel = ZetaDia.Me.Level;

            Logger.Write("Player leveled up, congrats! Your level is now: {0}",
                myLevel
                );

            if (myLevel == 2)
            {
                ZetaDia.Me.SetActiveSkill(SNOPower.Barbarian_HammerOfTheAncients, -1, 1);
                Logger.Write("Setting Hammer of the Ancients as Secondary");
            }

            if (myLevel == 3)
            {
                ZetaDia.Me.SetActiveSkill(SNOPower.Barbarian_Cleave, -1, 0);
                Logger.Write("Setting Cleave as Primary");
            }

            if (myLevel == 4)
            {
                ZetaDia.Me.SetActiveSkill(SNOPower.Barbarian_GroundStomp, -1, 2);
                Logger.Write("Setting Ground Stomp as Defensive");
            }

            if (myLevel == 8)
            {
                ZetaDia.Me.SetActiveSkill(SNOPower.Barbarian_Leap, -1, 2);
                Logger.Write("Setting Leap as Defensive");
            }

            if (myLevel == 9)
            {
                ZetaDia.Me.SetActiveSkill(SNOPower.Barbarian_AncientSpear, -1, 3);
                Logger.Write("Setting Ancient Spear as Might");
            }

            if (myLevel == 10)
            {
                ZetaDia.Me.SetTraits(SNOPower.Barbarian_Passive_Ruthless);
                Logger.Write("Setting Ruthless as Passive Skill");
            }
        }
    }
}
