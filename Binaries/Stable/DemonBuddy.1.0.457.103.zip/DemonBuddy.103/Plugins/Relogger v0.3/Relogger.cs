﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Zeta.Common.Plugins;
using Zeta.Internals;
using Zeta.Common;
using System.Windows;
using System.Threading;
using System.IO;
using Zeta;

namespace GugaPlugin
{
    class Relogger : IPlugin
    {
        public string Author { get { return "Guga"; } }
        public string Description { get { return "This plugin will automatically relog, when u DC.  Also clicks away Error Messages you get while playing"; } }
        public string Name { get { return "Relogger"; } }
        public Version Version { get { return new Version(0, 3); } }
        public bool Equals(IPlugin other) { return other.Name == Name && other.Version == Version; }
        public Window DisplayWindow
        {
            get
            {
                return null;
            }
        }
        public void OnDisabled()
        {
            Logging.Write("[" + Name + "]" + " v" + Version + " [OFF]");
            relogThread.Abort();
           // isEnabled = false;
            //Zeta.Common.Plugins.PluginManager.ReloadAllPlugins(Zeta.CommonBot.Settings.GlobalSettings.Instance.PluginsPath);
        }
        public void OnEnabled()
        {
            Logging.Write("[" + Name + "]" + " v" + Version + " [ON]");
            LoadAccDetails();
            relogThread = new Thread(Checker);
            isEnabled = true;
            relogThread.Start();
        }
        public void Checker()
        {
           
            while (isEnabled)
            {
                try
                {
                    Zeta.Internals.UIElement emailBox = Zeta.Internals.UIElement.FromHash(0xDE8625FCCFFDFC28);
                    Zeta.Internals.UIElement pwdBox = Zeta.Internals.UIElement.FromHash(0xBA2D3316B4BB4104);
                    Zeta.Internals.UIElement loginButton = Zeta.Internals.UIElement.FromHash(0x50893593B5DB22A9);
                    if (emailBox.IsVisible && pwdBox.IsVisible && loginButton.IsVisible)
                    {
                        emailBox.SetText(accountName);
                        pwdBox.SetText(password);
                        loginButton.Click();
                        Logging.Write("Relogging...");
                    }
                }
                catch (Exception e)
                {
                   // Logging.Write("[" + Name + "]" + " ERROR: " + e.Message);
                }
                try
                {
                    Zeta.Internals.UIElement okButton = Zeta.Internals.UIElement.FromHash(0xB4433DA3F648A992);
                    if (okButton.IsVisible)
                    {
                        Logging.Write("Pressing OK Button");
                        okButton.Click();
                    }
                }
                catch (Exception e)
                {
                    
                }
                Thread.Sleep(10000);
            }

        }
        public void OnInitialize()
        {

        }

        public void OnPulse()
        {

        }

        public void OnShutdown()
        {

        }
        public void LoadAccDetails()
        {
            Logging.Write("Loading Account Details...");
            StreamReader reader = new StreamReader("Plugins/Relogger/Account.cfg");
            while (!reader.EndOfStream)
            {
                string[] split = reader.ReadLine().Split('=');
                if (split != null)
                {
                    if (split[0] == "account")
                    {
                        accountName = split[1];
                    }
                    else if (split[0] == "password")
                    {
                        password = split[1];
                    }
                }
            }
            reader.Close();
        }
        private Thread relogThread;
        private string accountName;
        private string password;
        private bool isEnabled;
    }
}
