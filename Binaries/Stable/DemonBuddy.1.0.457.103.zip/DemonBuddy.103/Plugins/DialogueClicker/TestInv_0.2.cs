﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Threading;

using Zeta;
using Zeta.Common;
using Zeta.Common.Plugins;
using Zeta.Internals.Actors;

namespace TestInv
{
    public class TestInv : IPlugin 
    {
        WaitHandle flagStop = new AutoResetEvent(false);
        Thread checkthread;

        void LogDiags(string message)
        {
            Logging.WriteDiagnostic(string.Format("[{0}] {1}", Name, message));
        }

        void Log(string message)
        {
            Logging.Write(string.Format("[{0}] {1}", Name, message));
        }

        void CheckNotificationUI()
        {
            Log("Start CheckNotificationUI thread");
            do
            {
                try
                {
                    LogDiags("Check for Notification UI");
                    Zeta.Internals.UIElement ui = Zeta.Internals.UIElement.FromHash(0x4CC93A73A58BAFFF);
                    if (ui != null && ui.IsValid)
                    {
                        if (ui.IsVisible)
                        {
                            Log(String.Format("Detect UI = {0}, Visible = {1}", ui.Name, ui.IsVisible));

                            Zeta.Internals.UIElement Button = Zeta.Internals.UIElement.FromHash(0xB4433DA3F648A992);
                            if (Button != null && Button.IsValid)
                            {
                                //Log(String.Format("UI name = {0}, Visible = {1}", Button.Name, Button.IsVisible));
                                if (Button.IsVisible)
                                {
                                    Log("Notification OK clicked");
                                    Button.Click();
                                }                                
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                	//LogDiags(ex.Message);
                    //LogDiags(ex.StackTrace);
                }
            } while (!flagStop.WaitOne(10000, false));
            
            Log("Stop CheckNotificationUI thread");
        }

        public void OnDisabled()
        {
            Log("Disabled");
            ((AutoResetEvent)flagStop).Set();
        }
        public void OnEnabled()
        {
            Log("Enabled");
            if (checkthread!=null && checkthread.IsAlive)
            {
                Log("Kill old CheckNotificationUI thread");
                checkthread.Abort();
            }
            checkthread = new Thread(new ThreadStart(CheckNotificationUI));
            checkthread.Start();            
        }
        public void OnInitialize()
        {
            Log("Initalized");            
        }
        public void OnPulse()
        {
            //Log("OnPulse");            
        }
        public void OnShutdown()
        {
            Log("Shutdown");
            ((AutoResetEvent)flagStop).Set();
        }

        public string Author { get { return "neoz"; } }

        public string Description { get { return "neoz"; } }

        public Window DisplayWindow { get { return null; } }

        public string Name { get { return "NotificationOKClick Plugin"; } }

    	public System.Version Version { get { return new Version(0, 2); } }

        public bool Equals(IPlugin other)
        {
            return (other.Name == Name) && (other.Version == Version);
        }
    }
}
