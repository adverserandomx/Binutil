﻿using System.ComponentModel;
using System.IO;
using Zeta.Common.Xml;
using Zeta.XmlEngine;


namespace Belphegor.Settings
{
    [XmlElement("DemonHunterSettings")]
    public class DemonHunterSettings : XmlSettings
    {
        public DemonHunterSettings() :
            base(Path.Combine(Path.Combine(SettingsDirectory, "Belphegor"), "DemonHunterSettings.xml"))
        {
        }

        [XmlElement("SpamSmokeScreen")]
        [DefaultValue(false)]
        public bool SpamSmokeScreen { get; set; }

        [XmlElement("SmokeScreenHP")]
        [DefaultValue(0.50)]
        public int SmokeScreenHP { get; set; }

        [XmlElement("ShadowPowerHp")]
        [DefaultValue(0.50)]
        public int ShadowPowerHp { get; set; }

        [XmlElement("PreparationHP")]
        [DefaultValue(0.5)]
        public double PrperationHP { get; set; }


    }
}
