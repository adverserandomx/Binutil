﻿using System.ComponentModel;
using System.IO;
using Zeta.Common.Xml;
using Zeta.XmlEngine;

namespace Belphegor.Settings
{
    [XmlElement("BelphegorSettings")]
    internal class BelphegorSettings : XmlSettings
    {
        public BelphegorSettings() :
            base(Path.Combine(Path.Combine(SettingsDirectory, "Belphegor"), "BelphegorSettings.xml"))
        {
        }

        private static BelphegorSettings _instance;

        public static BelphegorSettings Instance { get { return _instance ?? (_instance = new BelphegorSettings()); } }

        [XmlElement("HealthPotionPct")]
        [DefaultValue(0.4)]
        public double HealthPotionPct { get; set; }

        #region Class Late-Loading Wrappers
        private BarbarianSettings _barbSettings;
        private DemonHunterSettings _dhSettings;
        private MonkSettings _monkSettings;
        private WitchDoctorSettings _wdSettings;
        private WizardSettings _wizSettings;

        [Browsable(false)]
        public BarbarianSettings Barbarain { get { return _barbSettings ?? (_barbSettings = new BarbarianSettings()); } }

        [Browsable(false)]
        public DemonHunterSettings DemonHunter { get { return _dhSettings ?? (_dhSettings = new DemonHunterSettings()); } }

        [Browsable(false)]
        public MonkSettings Monk { get { return _monkSettings ?? (_monkSettings = new MonkSettings()); } }

        [Browsable(false)]
        public WitchDoctorSettings WitchDoctor { get { return _wdSettings ?? (_wdSettings = new WitchDoctorSettings()); } }

        [Browsable(false)]
        public WizardSettings Wizard { get { return _wizSettings ?? (_wizSettings = new WizardSettings()); } }
        #endregion
    }
}
