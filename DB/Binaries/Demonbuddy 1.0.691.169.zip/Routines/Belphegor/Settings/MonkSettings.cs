﻿using System.ComponentModel;
using System.IO;
using Zeta.Common.Xml;
using Zeta.XmlEngine;

namespace Belphegor.Settings
{
    [XmlElement("MonkSettings")]
    public class MonkSettings : XmlSettings
    {
        public MonkSettings()
            : base(Path.Combine(Path.Combine(SettingsDirectory, "Belphegor"), "MonkSettings.xml"))
        {
        }

        [XmlElement("SpamMantra")]
        [DefaultValue(false)]
        public bool SpamMantra { get; set; }

        [XmlElement("SerenityHp")]
        [DefaultValue(0.6)]
        public double SerenityHp { get; set; }

        [XmlElement("BreathOfHeavenHp")]
        [DefaultValue(0.7)]
        public double BreathOfHeavenHp { get; set; }

        [XmlElement("BoHBlazingWrath")]
        [DefaultValue(false)]
        public bool BoHBlazingWrath { get; set; }
    }
}
