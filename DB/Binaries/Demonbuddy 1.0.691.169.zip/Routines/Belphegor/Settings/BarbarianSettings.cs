﻿using System.ComponentModel;
using System.IO;
using Zeta.Common.Xml;
using Zeta.XmlEngine;

namespace Belphegor.Settings
{
    [XmlElement("BarbarianSettings")]
    public class BarbarianSettings : XmlSettings
    {
        public BarbarianSettings()
            : base(Path.Combine(Path.Combine(SettingsDirectory, "Belphegor"), "BarbarianSettings.xml"))
        {
        }

        [XmlElement("SpamWarCry")]
        [DisplayName("Spam War Cry")]
        [Category("Tactics")]
        [DefaultValue(false)]
        [Description("Spam War Cry on cool down rather than check if you have the buff, False Default")]
        public bool SpamWarCry { get; set; }

        [XmlElement("IgnorePainPct")]
        [Category("Defensive")]
        [DisplayName("Ignore Pain %")]
        [DefaultValue(0.4)]
        [Description("The health % on which to use ignore pain, 0.4 default")]
        public double IgnorePainPct { get; set; }

        [XmlElement("RageSkillsAoeCount")]
        [DisplayName("Rage Skills AoE Count")]
        [Category("Rage")]
        [DefaultValue(4)]
        [Description("The number of normal mobs in an area before you use Rage Skills (WotB ect..)")]
        public int RageSkillsAoeCount { get; set; }
    }
}
