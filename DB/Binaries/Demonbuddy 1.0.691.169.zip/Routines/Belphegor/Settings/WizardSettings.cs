﻿using System.ComponentModel;
using System.IO;
using Zeta.Common.Xml;
using Zeta.XmlEngine;

namespace Belphegor.Settings
{
    [XmlElement("WizardSettings")]
    public class WizardSettings : XmlSettings
    {
        public WizardSettings() :
            base(Path.Combine(Path.Combine(SettingsDirectory, "Belphegor"), "WizardSettings.xml"))
        {
        }

        [XmlElement("DiamondSkinHp")]
        [DefaultValue(0.5)]
        public double DiamondSkinHp { get; set; }

        [XmlElement("MirrorImageHp")]
        [DefaultValue(0.5)]
        public double MirrorImageHp { get; set; }

        [XmlElement("SlowTimeHp")]
        [DefaultValue(0.5)]
        public double SlowTimeHp { get; set; }

        
    }
}
