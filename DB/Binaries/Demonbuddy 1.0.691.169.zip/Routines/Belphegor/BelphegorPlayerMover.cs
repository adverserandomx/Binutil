﻿//using System;
//using Zeta;
//using Zeta.Common;
//using Zeta.Common.Helpers;
//using Zeta.CommonBot;
//using Zeta.Internals.Actors;
//using Zeta.Navigation;

//namespace Belphegor
//{
//    public class BelphegorPlayerMover : IPlayerMover
//    {
//        #region Implementation of IPlayerMover

//        public void MoveTowards(Vector3 to)
//        {
//            if (_LagTimer.IsFinished)
//            {
//                if (ZetaDia.Me.Position.Distance(to) > 20f && ZetaDia.Me.Position.Distance(to) < 35f && notInCombat)
//                {
//                    if (PowerManager.CanCast(SNOPower.Wizard_Teleport))
//                    {
//                        ZetaDia.Me.UsePower(SNOPower.Wizard_Teleport, to, ZetaDia.Me.WorldDynamicId);
//                        Logging.WriteVerbose("Belphegor: Teleporting to {0}", to.ToString());
//                        Navigator.Clear();
//                        _LagTimer.Reset();
//                        return;
//                    }

//                    if (PowerManager.CanCast(SNOPower.DemonHunter_Vault))
//                    {
//                        ZetaDia.Me.UsePower(SNOPower.DemonHunter_Vault, to, ZetaDia.Me.WorldDynamicId);
//                        Logging.WriteVerbose("Belphegor: Vault to {0}", to.ToString());
//                        Navigator.Clear();
//                        _LagTimer.Reset();
//                        return;
//                    }
//                }
//            }

//            ZetaDia.Me.Movement.MoveActor(to);
//        }

//        public void MoveStop()
//        {
//            ZetaDia.Me.Movement.MoveActor(ZetaDia.Me.Position);
//        }

//        #endregion


//        #region Timers
//        static BelphegorPlayerMover()
//        {
//            GameEvents.OnGameLeft += ResetTimers;
//            GameEvents.OnPlayerDied += ResetTimers;
//        }

//        static void ResetTimers(object sender, EventArgs e)
//        {
//            _LagTimer.Stop();
//        }

//        private static WaitTimer _LagTimer = new WaitTimer(TimeSpan.FromSeconds(1));

//        #endregion


//        private static bool notInCombat
//        {
//            get
//            {
//                if (CombatTargeting.Instance.FirstNpc == null)
//                    return true;

//                if (CombatTargeting.Instance.FirstNpc.Distance > 35f)
//                    return true;

//                else return false;
//            }
//        }
//    }
//}
