﻿using System.ComponentModel;
using System.IO;
using Zeta.Common.Xml;
using Zeta.XmlEngine;

namespace Belphegor.Settings
{
    [XmlElement("WitchDoctorSettings")]
    public class WitchDoctorSettings : XmlSettings
    {
        public WitchDoctorSettings()
            : base(Path.Combine(Path.Combine(SettingsDirectory, "Belphegor"), "WitchDoctorSettings.xml"))
        {
        }

        [XmlElement("SacrificeHp")]
        [DefaultValue(0.5d)]
        public double SacrificeHp { get; set; }

    }
}
