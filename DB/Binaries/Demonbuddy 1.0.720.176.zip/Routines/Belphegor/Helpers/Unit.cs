﻿using System.Collections.Generic;
using Zeta;
using Zeta.Internals.Actors;
using System.Linq;

namespace Belphegor.Helpers
{
    internal static class Unit
    {
        /// <summary>
        /// Checks if the mob is Elite or Rare
        /// </summary>
        /// <param name="unit">DiaUnit</param>
        /// <returns>True if Current unit is Elite</returns>
        public static bool IsElite(this DiaUnit unit)
        {
            if (unit.CommonData.MonsterAffixes.HasFlag(MonsterAffixes.Elite))
            {
                Logger.WriteVerbose("{0} Is an Elite Mob", unit.Name);
                return true;
            }
            if (unit.CommonData.MonsterAffixes.HasFlag(MonsterAffixes.Rare))
            {
                Logger.WriteVerbose("{0} Is a Rare Mob", unit.Name);
                return true;
            }
            if (unit.CommonData.MonsterAffixes.HasFlag(MonsterAffixes.Unique))
            {
                Logger.WriteVerbose("{0} Is a Unique Mob", unit.Name);
                return true;
            }
            if (unit.Name.StartsWith("treasureGoblin"))
            {
                Logger.WriteVerbose("Mob is a Treasure Goblin");
                return true;
            }

            return false;
        }

        /// <summary>
        /// Checks if the mob is Elite or Rare && with range
        /// </summary>
        /// <param name="unit">DiaUnit</param>
        /// <param name="range">Range from us to unit</param>
        /// <returns>True if Current usint is Elite && unit is in rnage</returns>
        public static bool IsElite(this DiaUnit unit, float range)
        {
            return IsElite(unit) && unit.Distance <= range;
        }

        /// <summary>
        /// Checks if we are Blind, Feared, Frozen, Stunned or Rooted
        /// </summary>
        public static bool MeIncapacited
        {
            get
            {
                var me = ZetaDia.Me;
                return me.IsFeared || me.IsStunned || me.IsFrozen || me.IsBlind || me.IsRooted;
            }
        }

        /// <summary>
        /// Gets the minions of the local player.
        /// </summary>
        /// <remarks>Created 2012-07-11</remarks>
        public static IEnumerable<DiaUnit> Minions
        {
            get
            {
                int dynId = ZetaDia.Me.CommonData.DynamicId;
                var minions = ZetaDia.Actors.GetActorsOfType<DiaUnit>().Where(u => u.SummonedByACDId == dynId);
                return minions;
            }
        }

        /// <summary>
        /// Determines whether you have specified pet summoned.
        /// </summary>
        /// <param name="petName">Name of the pet.</param>
        /// <returns>
        ///   <c>true</c> if you have specified pet summoned; otherwise, <c>false</c>.
        /// </returns>
        /// <remarks>Created 2012-07-11</remarks>
        public static bool HasPet(string petName)
        {
            return PetCount(petName) != 0;
        }

        /// <summary>
        /// Counts how many minions with the provided name you got summoned.
        /// </summary>
        /// <param name="petName">Name of the pet.</param>
        /// <returns></returns>
        /// <remarks>Created 2012-07-11</remarks>
        public static int PetCount(string petName)
        {
            return Minions.Count(m => m.Name.Contains(petName));
        }
    }
}
